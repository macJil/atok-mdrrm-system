<?php
class db{

    public function __construct(
       private string $customer_name,
       private string $contact_number,	
       private string $device_type,	
       private string $device_model,
       private string $issue_description,	
       private string $status,	
       private  $date_received
       

    )
    {
       $this->customer_name = $customer_name;
       $this->contact_number= $contact_number;	
       $this->device_type = $device_type;
       $this->device_model =$device_model;
       $this->issue_description =$issue_description;	
       $this->status = $status;
       $this->date_received = $date_received;
       
    }
    

    public function connect(){
        try{
            $pdo = new PDO( 
            "mysql:host=localhost;dbname=repair_shop_lab", 
            "root", 
            "" 
            ); 
            $pdo->setAttribute(PDO::ERRMODE_EXCEPTION, PDO::FETCH_ASSOC);

        } catch(PDOException $e){
            die("Connection Failed" . $e->getMessage());
        }
        return $pdo;

    }

    public function create_job(){
        $sql = "INSERT INTO job_orders(customer_name,contact_number,device_type,device_model,issue_description,status,date_received)
        VALUES (?,?,?,?,?,?,?)";
        try{
            
            $stmt = $this->connect()->prepare($sql);
            $stmt = $stmt->execute([
            $this->customer_name,
            $this->contact_number,
            $this->device_type,
            $this->device_model,
            
            $this->issue_description,
            $this->status,
            $this->date_received
            
        ]);
        if($stmt){
                return "<script>alert('Successful');</script>";
            } else {
                return "<script>alert('Unsuccessful');</script>";
            }
        } catch (PDOException $e){
            die("There is an ERROR!" . $e->getMessage());

        }
        
    }
    public function display_job(){
        $sql = "SELECT * FROM job_orders";
        try{
            $stmt = $this->connect()->query($sql);
            return $stmt;
        } catch (PDOException $e){
            die("There is an ERROR!" . $e->getMessage());

        }
    }
    public function view_one_job(int $id){
        $sql = "SELECT * FROM job_orders WHERE id = ? ";
        try{
            $stmt = $this->connect()->prepare($sql);
            $stmt = $stmt->execute([$id]);
        } catch (PDOException $e){
            die("There is an ERROR!" . $e->getMessage());

        }

    }public function search_job(string $job){
        $sql = "SELECT * FROM job_orders WHERE id LIKE %?% ";
        try{
            $stmt = $this->connect()->prepare($sql);
            $stmt = $stmt->execute([$job]);
        } catch (PDOException $e){
            die("There is an ERROR!" . $e->getMessage());

        }

    }

}


?>