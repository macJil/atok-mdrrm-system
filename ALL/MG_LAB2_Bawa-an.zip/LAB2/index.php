<?php
require_once "db.php";

if(isset($_POST['submit'])){
    $job = new db(
        htmlspecialchars($_POST['customer_name']),
        htmlspecialchars($_POST['contact_number']),
        htmlspecialchars($_POST['device_type']),
        htmlspecialchars($_POST['device_model']),
        htmlspecialchars($_POST['issue_description']),
        htmlspecialchars($_POST['status']),
        date("d/m/y")
    );

    echo $job->create_job();
    
}


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div>
        <form action="" method="post">
            <table>
                
                
                <tr>
                    <th>Customer</th>
                    <td>
                        <input type="text" name="customer_name" required>
                    </td>
                </tr>
                <tr>
                    <th>Contact number</th>
                    <td>
                        <input required type="text" name="contact_number">
                    </td>
                </tr>
                <tr>
                    <th>Device type</th>
                    <td>
                        <input required type="text" name="device_type">
                    </td>
                </tr>
                <tr>
                    <th>Device model</th>
                    <td>
                        <input required type="text" name="device_model">
                    </td>
                </tr>
                <tr>
                    <th>Issue description</th>
                    <td>
                        <input required type="text" name="issue_description">
                    </td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td>
                        <input required type="text" name="status">
                    </td>
                </tr>
                <tr>
                   <td>
                    <button name="submit">Submit</button>
                   </td>
                </tr>
            </table>
        </form>
    </div>
    <div>
        <form action="" method="post">
            <table>
            
                <tr>
                    <th>Customer</th>
                    <th>Device</th>
                    <th>Issue</th>
                    <th>Status</th>
                    <th>Date Received</th>
                    <th>Actions</th>
                </tr>
                <?php foreach($rows as $row):?>
                    <tr>
                        <td></td>
                    </tr>
                <?php endforeach?>
            </table>
        </form>
    </div>
</body>
</html>